#!/bin/bash
# // Hayoloh mau ngapain
# // Limit IP Mod By XDXL STORE

function send_log(){
protocol="$1"
CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="
<code>────────────────────</code>
<b>  ⚠️ NOTIF MULTI LOGIN $protocol ⚠️</b>
<code>────────────────────</code>
<code>Username : </code><code>$user</code>
<code>Limit IP : </code><code>$iplimit Device</code>
<code>Login IP : </code><code>$cekcek Device</code>
<code>────────────────────</code>
<code>Akun terkunci selama 15 menit</code>
<code>────────────────────</code>
"'&reply_markup={"inline_keyboard":[[{"text":" ⛈️ ɢʀᴏᴜᴘ ⛈️ ","url":"https://t.me/xd_tunnel"}]]}' 
curl -s --max-time 10 -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
}
function vmip(){
echo -n > /var/log/xray/access.log
sleep 4
data=( `ls /etc/xray/limit/vmess/ip`);
for user in "${data[@]}"
do
iplimit=$(cat /etc/xray/limit/vmess/ip/$user)
ehh=$(cat /var/log/xray/access.log | grep "$user" | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | sort | uniq);
cekcek=$(echo -e "$ehh" | wc -l);
if [[ $cekcek -gt $iplimit ]]; then
exp=$(grep -w "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
uuid=$(grep -w "^#! $user" "/etc/xray/config.json" | cut -d ' ' -f 4 | sort | uniq)
sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
systemctl restart xray >> /dev/null 2>&1
jum2=$(cat /tmp/ipvmess.txt | wc -l )
send_log VMESS
echo "resvm $user $exp $uuid && systemctl restart xray" | at now + 15 minutes > /dev/null
else
echo ""
fi
sleep 0.1
done
}
function vlip(){
echo -n > /var/log/xray/access.log
sleep 4
data=( `ls /etc/xray/limit/vless/ip`);
for user in "${data[@]}"
do
iplimit=$(cat /etc/xray/limit/vless/ip/$user)
ehh=$(cat /var/log/xray/access.log | grep "$user" | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | sort | uniq);
cekcek=$(echo -e "$ehh" | wc -l);
if [[ $cekcek -gt $iplimit ]]; then
exp=$(grep -w "^#& $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
uuid=$(grep -w "^#& $user" "/etc/xray/config.json" | cut -d ' ' -f 4 | sort | uniq)
sed -i "/^#& $user $exp/,/^},{/d" /etc/xray/config.json
systemctl restart xray >> /dev/null 2>&1
jum2=$(cat /tmp/ipvless.txt | wc -l)
send_log VLESS
echo "resvl $user $exp $uuid && systemctl restart xray" | at now + 15 minutes > /dev/null
else
echo ""
fi
sleep 0.1
done
}
function trip(){
echo -n > /var/log/xray/access.log
sleep 4
data=( `ls /etc/xray/limit/trojan/ip`);
for user in "${data[@]}"
do
iplimit=$(cat /etc/xray/limit/trojan/ip/$user)
ehh=$(cat /var/log/xray/access.log | grep "$user" | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | sort | uniq);
cekcek=$(echo -e "$ehh" | wc -l);
if [[ $cekcek -gt $iplimit ]]; then
exp=$(grep -w "^#! $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
uuid=$(grep -w "^#! $user" "/etc/xray/config.json" | cut -d ' ' -f 4 | sort | uniq)
sed -i "/^#! $user $exp/,/^},{/d" /etc/xray/config.json
systemctl restart xray >> /dev/null 2>&1
jum2=$(cat /tmp/iptrojan.txt | wc -l)
echo "restr $user $exp $uuid && systemctl restart xray" | at now + 15 minutes > /dev/null
send_log TROJAN
else
echo ""
fi
sleep 0.1
done
}
function xd-sship() {
mulog=$(fvssh)
sleep 4
data=( `ls /etc/xray/limit/ssh/ip`);
for user in "${data[@]}"
do
iplimit=$(cat /etc/xray/limit/ssh/ip/$user)
cekcek=$(echo -e "$mulog" | grep $user | wc -l);
if [[ $cekcek -gt $iplimit ]]; then
egrep "^$user" /etc/passwd >/dev/null
passwd -l $user
systemctl restart ws
send_log SSH
echo "passwd -u $user && systemctl restart ws-dropbear ws-stunnel" | at now + 15 minutes > /dev/null
else
echo > /dev/null
fi
sleep 0.1
done
}

vmip
vlip
trip
xd-sship
